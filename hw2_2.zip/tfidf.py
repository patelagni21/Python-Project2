import re
from collections import Counter

preproc_prefix = 'mine_preproc_'
tfidf_preifx   = 'mine_tfidf_'

def round_n_dec( x, n ):
	rounded = ( round( 10**n * x ) )/10**n
	if n == 0:
		return int( rounded )
	else:
		return rounded

def dbg( s ):
	#print( s )
	return

def process_match( match ):
	ch = match.group()
	if len( ch ) != 1 :
		if ch[ 0 ] == ' ':
			dbg( 'got ' + ch + ' returning single space' )
			return ' '
		else:
			dbg( 'got hyper returning empty' )
			return ''
	else:
		ascii = ord( ch )
		if ascii >=65 and ascii <= 90:
			dbg( 'got ' + ch + ' returning down' )
			return chr( ascii + 32 )
		if ch == '_' or ch == ' ' or ( ascii >= 97 and ascii <= 122 ) or ( ascii >= 48 and ascii <= 57 ):
			dbg( 'got ' + ch + ' returning as is' )
			return ch
		elif ch == '\n':
			dbg( 'got newline, returning same' )
			return '\n'
		else:
			dbg( 'got ' + ch + ' returning blank' )
			return ''


def clean( contents ):
	cleaned = re.sub( r'(\bhttp://.*\b|\bhttps://.*\b|\s+|.)', process_match, contents )
	return cleaned

def remove_stop_suffix( cleaned ):
	stoplist = []
	with open( "stopwords.txt" ) as stop_f:
		for w in stop_f:
			stoplist.append( w.strip() )

	suffix_regex = re.compile( r'ly$|ing$|ment$' )

	return ' '.join( 
			[ 
				re.sub( suffix_regex, '', w ) 
					for w in cleaned.split() 
					if w not in stoplist 
			] 
	)

def two_one():
	freq = Counter( lst ) 
	{ w:(f/len( lst )) for (w,f) in freq.items()  }


def main():
	docs = []
	with open( 'tfidf_docs.txt' ) as tfidf_docs_f:
		for d in tfidf_docs_f:
			if d.strip() != '':
				docs.append( d.strip() )

		for doc in docs:
			with open( doc ) as doc_f:
				dbg( '======' + doc + '======' )
				doc_contents = doc_f.read()
				dbg( '-----contents-----' )
				dbg( doc_contents )
				doc_contents_cleaned = clean( doc_contents )
				dbg( '-----cleaned-----' )
				dbg( doc_contents_cleaned )
				doc_contents_pruned = remove_stop_suffix( doc_contents_cleaned )
				dbg( '-----pruned-----' )
				dbg( doc_contents_pruned )
				with open( preproc_prefix + doc, 'w' ) as preproc_w_f:
					preproc_w_f.write( doc_contents_pruned )

		tf = {}

		# Term frequency
		for doc in docs:
			with open( preproc_prefix + doc ) as preproc_f:
				preproc_doc = preproc_f.read().strip()
				preproc_doc_words = preproc_doc.split( ' ' )
				total_doc_words = len( preproc_doc_words )
				tf_init = Counter( preproc_doc_words )
				tf[ doc ] = { 
					k: 
					round_n_dec( v / total_doc_words , 2 )
					for k , v 
					in tf_init.items()
				}

		# Enumerate all words
		all_words = []
		for doc in docs:
			doc_words = list( tf[ doc ].keys()  )
			all_words = all_words + doc_words

		# Inverse document frequency
		idf = {}
		for w in all_words:
			found = 0
			for doc in docs:
				if w in tf[ doc ]:
					found += 1
		
			w_idf = 0
		
			if found != 0:
				w_idf = w_idf + len( docs ) / found
		
			idf[ w ] = w_idf

		tf_idf = {}

		for doc in docs:
			tf_idf[ doc ] = {}

			for doc_w in tf[ doc ].keys():
				tf_idf[ doc ][ doc_w ] = round_n_dec( tf[ doc ][ doc_w ] * idf[ doc_w ], 2 )

			top_5 = sorted( 
				tf_idf[ doc ].items(),
				key = lambda pair: ( -pair[ 1 ], pair[ 0 ] )
			)[ 0: 5 ]

			with open( tfidf_preifx + doc, 'w' ) as tfidf_w_f:
				tfidf_w_f.write( str( top_5 ) )

main()

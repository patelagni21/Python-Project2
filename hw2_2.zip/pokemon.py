import csv 
from collections import Counter

def one( poks ):
	fire_40plus_count = len( [ 1  for p in poks if p[ 'type' ] == 'fire' and  float(p[ 'level' ]) >= 40  ] )
	fire_count = len( [ 1  for p in poks if p[ 'type' ] == 'fire' ] )
	s = 'Percentage of fire type Pokemons at or above level 40 = ' +  str( round( 100 * fire_40plus_count / fire_count ) )
	with open( 'pokemon1.txt', 'w' ) as one_f:
		one_f.write( s )

def two( poks ):
	weakness_type_ctr_map = {}
	for p in poks:
		weakness = p[ 'weakness' ]
		tpe = p[ 'type' ]
		if weakness not in weakness_type_ctr_map:
			weakness_type_ctr_map[ weakness ] = Counter()
		weakness_type_ctr_map[ weakness ].update( { tpe: 1 } )

	weakness_most_common_type_map = { 
		w: 
		sorted( 
			type_ctr.items(),  
			key = lambda pair: (-pair[1], pair[0] )   
		)[ 0 ][ 0 ] 
		for w, type_ctr in weakness_type_ctr_map.items() 
	}

	for idx, p in enumerate( poks ):
		tpe = p[ 'type' ]
		weakness = p[ 'weakness' ]
		if tpe == 'NaN':
			poks[ idx ][ 'type' ] = weakness_most_common_type_map[ weakness ]

def round_one_dec( x ):
	return ( round( 10 * x ) )/10

def three( poks ):
	threshold = 40.0
	above_threshold = [ p for p in poks if float( p[ 'level' ] ) > threshold ];
	below_threshold = [ p for p in poks if float( p[ 'level' ] ) <= threshold ];
	
	def avg_hp_atk_defns( sublist ):
		running_sum   = { 'hp': 0, 'atk': 0, 'defns': 0 }
		running_count = { 'hp': 0, 'atk': 0, 'defns': 0 }

		for pok in sublist:
			atk = pok[ 'atk' ]
			if atk != 'NaN':
				atk = float( atk )
				running_sum[ 'atk' ] += atk
				running_count[ 'atk' ] += 1
		
			defns = pok[ 'def' ]
			if defns != 'NaN':
				defns = float( defns )
				running_sum[ 'defns' ] += defns
				running_count[ 'defns' ] += 1

			hp = pok[ 'hp' ]
			if hp != 'NaN':
				hp = float( hp )
				running_sum[ 'hp' ] += hp
				running_count[ 'hp' ] += 1

		avg = {
				'hp'    : round_one_dec( running_sum[ 'hp'    ] / running_count[ 'hp'    ] ) ,
				'atk'   : round_one_dec( running_sum[ 'atk'   ] / running_count[ 'atk'   ] ) ,
				'def'   : round_one_dec( running_sum[ 'defns' ] / running_count[ 'defns' ] ) ,
		}

		return avg

	at_avg = avg_hp_atk_defns( above_threshold )
	bt_avg = avg_hp_atk_defns( below_threshold )

	for idx, p in enumerate( poks ):
		hp    = p[ 'hp'    ]
		defns = p[ 'def'   ]
		atk   = p[ 'atk'   ]
		level = float( p[ 'level' ] )

		if level > threshold:
			if hp == 'NaN':
				poks[ idx ][ 'hp' ] = at_avg[ 'hp' ]
			if defns == 'NaN':
				poks[ idx ][ 'def' ] = at_avg[ 'def' ]
			if atk  == 'NaN':
				poks[ idx ][ 'atk' ] = at_avg[ 'atk' ]
		else:
			if hp == 'NaN':
				poks[ idx ][ 'hp' ] = bt_avg[ 'hp' ]
			if defns == 'NaN':
				poks[ idx ][ 'def' ] = bt_avg[ 'def' ]
			if atk == 'NaN':
				poks[ idx ][ 'atk' ] = bt_avg[ 'atk' ]


def four( poks ):
	tpe_personality_list_map = {}
	for p in poks:
		tpe = p[ 'type' ]
		personality = p[ 'personality' ]

		if tpe not in tpe_personality_list_map:
			tpe_personality_list_map[ tpe ] = set()
		tpe_personality_list_map[ tpe ].update( { personality } )
	
	s = 'Pokemon type to personality mapping:'  + '\n\n'

	for tpe, personality_list in sorted( tpe_personality_list_map.items() ):
		s += ( '\t' + tpe + ': ' )
		s += ( ', '.join( [ p for p in sorted( personality_list ) ] ) )
		s += '\n'

	with open( 'pokemon4.txt', 'w' ) as four_f:
		four_f.write( s )


def five( poks ):
	stage3_hp_list = [ float( p[ 'hp' ]  ) for p in poks if float( p[ 'stage' ] ) == 3.0 ]
	stage3_hp_avg  = round( sum( stage3_hp_list ) / len( stage3_hp_list ) )

	s = 'Average hit point for Pokemons of stage 3.0 = ' + str( stage3_hp_avg ) 

	with open( 'pokemon5.txt', 'w' ) as five_f:
		five_f.write( s )

def main():
	with open( "pokemonTrain.csv" ) as pm_f:
		pm_r = csv.DictReader( pm_f )
		poks = []
		for row in pm_r:
			poks.append( row )

	one( poks )
	two( poks )
	three( poks )
	four( poks )
	five( poks )


main()

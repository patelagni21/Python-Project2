import csv
from collections import Counter

def round_n_dec( x, n ):
	rounded = ( round( 10**n * x ) )/10**n
	if n == 0:
		return int( rounded )
	else:
		return rounded


def one( cv_data ):
	for idx, cv_r in enumerate( cv_data ):
		age = cv_r[ 'age' ]
		if str( age ).find( '-' ) >= 0 :
			age_l, age_u = age.split( '-' )
			age = round( ( int( age_l ) + int( age_u ) ) / 2 )
			cv_data[ idx ][ 'age' ] = str( age )

def date_d_to_m_first( d ):
	dd,mm,yyyy = d.split( '.' )
	return '.'.join( [ mm, dd, yyyy ] )

def two( cv_data ):
	for idx, cv_r in enumerate( cv_data ):
		dos = date_d_to_m_first( cv_r[ 'date_onset_symptoms'     ] )
		dah = date_d_to_m_first( cv_r[ 'date_admission_hospital' ] )
		dc  = date_d_to_m_first( cv_r[ 'date_confirmation'       ] )

		cv_data[ idx ][ 'date_onset_symptoms'     ] = dos 
		cv_data[ idx ][ 'date_admission_hospital' ] = dah 
		cv_data[ idx ][ 'date_confirmation'       ] = dc  

def three( cv_data ):
	pc_latlong_running_count = {}
	pc_latlong_running_sum   = {}

	for cv_r in cv_data:
		country, province = ( cv_r[ 'country' ], cv_r[ 'province' ] )
		latitude, longitude = ( cv_r[ 'latitude' ], cv_r[ 'longitude' ] )
		if (country, province) not in pc_latlong_running_count:
			pc_latlong_running_count[ (country, province) ]  = { 'latitude': 0, 'longitude': 0 }
			pc_latlong_running_sum[ (country, province) ] = { 'latitude': 0, 'longitude': 0 }
		if longitude != 'NaN':
			pc_latlong_running_sum[ (country, province) ][ 'longitude' ] += float( longitude )
			pc_latlong_running_count[ (country, province) ][ 'longitude' ] += 1
		if latitude != 'NaN':
			pc_latlong_running_sum[ (country, province) ][ 'latitude' ] += float( latitude )
			pc_latlong_running_count[ (country, province) ][ 'latitude' ] += 1

	pc_latlong_avg = {}	

	for pc in pc_latlong_running_sum.keys():
		pc_latlong_avg[ pc ] = {}

		pc_latitude_sum = pc_latlong_running_sum[ pc ][ 'latitude' ]
		pc_latitude_count = pc_latlong_running_count[ pc ][ 'latitude' ]
		pc_latlong_avg[ pc ][ 'latitude' ] = round_n_dec( pc_latitude_sum / pc_latitude_count, 2 )

		pc_longitude_sum = pc_latlong_running_sum[ pc ][ 'longitude' ]
		pc_longitude_count = pc_latlong_running_count[ pc ][ 'longitude' ]
		pc_latlong_avg[ pc ][ 'longitude' ] = round_n_dec( pc_longitude_sum / pc_longitude_count, 2 )

	for idx, cv_r in enumerate( cv_data ):
		country, province = ( cv_r[ 'country' ], cv_r[ 'province' ] )
		latitude, longitude =  ( cv_r[ 'latitude' ], cv_r[ 'longitude' ] )

		if longitude == 'NaN':
			print( idx, 'has long nan' )
			proxy_longitude = pc_latlong_avg[ pc ][ 'longitude' ]
			cv_data[ idx ][ 'longitude' ] = proxy_longitude
		
		if latitude == 'NaN':
			print( idx, 'has lat nan' )
			proxy_latitude = pc_latlong_avg[ pc ][ 'latitude' ]
			cv_data[ idx ][ 'latitude' ] = proxy_latitude
		

def four( cv_data ): 
	pc_citylist = {}
	pc_citymost = {}
	for cv_r in cv_data:
		country, province = ( cv_r[ 'country' ], cv_r[ 'province' ] )
		city = cv_r[ 'city' ]

		if (country, province) not in pc_citylist:
			pc_citylist[ (country, province) ] = Counter()

		if city != 'NaN':
			pc_citylist[ (country, province) ].update( { city } )

	for pc in pc_citylist.keys():
		pc_citymost[ pc ] = sorted( 
			pc_citylist[ pc ].items(),
			key = lambda pair: ( -pair[ 1 ], pair[ 0 ] )
		)[ 0 ][ 0 ]

	for idx, cv_r in enumerate( cv_data ):
		country, province = ( cv_r[ 'country' ], cv_r[ 'province' ] )
		city = cv_r[ 'city' ]
		if city == 'NaN':
			cv_data[ idx ][ 'city' ] = pc_citymost[ (country, province) ] 

def five( cv_data ): 
	pc_symptomslist = {}
	pc_symptomsmost = {}
	for cv_r in cv_data:
		country, province = ( cv_r[ 'country' ], cv_r[ 'province' ] )
		symptoms = cv_r[ 'symptoms' ]

		if (country, province) not in pc_symptomslist:
			pc_symptomslist[ (country, province) ] = Counter()

		if symptoms != 'NaN':
			all_symptoms = [ single.strip() for single in symptoms.split( ';' ) ]
			pc_symptomslist[ (country, province) ].update( all_symptoms )

	for pc in pc_symptomslist.keys():
		pc_symptomsmost[ pc ] = sorted( 
			pc_symptomslist[ pc ].items(), 
			key = lambda pair: ( -pair[ 1 ], pair[ 0 ] )
		)[ 0 ][ 0 ]

	for idx, cv_r in enumerate( cv_data ):
		country, province = ( cv_r[ 'country' ], cv_r[ 'province' ] )
		symptoms = cv_r[ 'symptoms' ]
		if symptoms == 'NaN':
			cv_data[ idx ][ 'symptoms' ] = pc_symptomsmost[ (country, province) ] 


def main():
	covid_fieldNames = []
	with open( "covidTrain.csv" ) as cv_f:
		cv_r = csv.DictReader( cv_f )
		covid_fieldNames = cv_r.fieldnames 
		cv_data = []
		for row in cv_r:
			cv_data.append( row )

	one( cv_data )
	two( cv_data )
	three( cv_data )
	four( cv_data )
	five( cv_data )

	with open( 'covidResult.csv', 'w' ) as covidResult_f:
		cv_w = csv.DictWriter( covidResult_f, covid_fieldNames )
		cv_w.writeheader()
		cv_w.writerows( cv_data )

main()
